﻿using System.Windows.Forms;

namespace ThisIsWin11
{
    public partial class ComponentsWindow : Form
    {
        public ComponentsWindow()
        {
            InitializeComponent();
        }
    }
}